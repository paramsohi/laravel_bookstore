<?php $__env->startSection('content'); ?>
<div class="container">

<nav class="navbar navbar-expand-lg navbar-light bg-light">

  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
  <div class="navbar-nav">
      <a class="nav-item nav-link "href="<?php echo e(route('admin.home')); ?>">Dashboard <span class="sr-only"></span></a>
      <a class="nav-item nav-link " href="<?php echo e(route('admin.viewbooks')); ?>">View books</a>
      <a class="nav-item nav-link active" href="<?php echo e(route('admin.addbook')); ?>">Add book</a>
    </div>
  </div>
</nav>

    <div class="row justify-content-center">
        <div class="col-md-8">
            
          
  <h1>Add Book</h1>

  <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>


        <?php if(session('success')): ?>
        <div class="alert alert-success">
        <ul>
        <li><?php echo e(session('success')); ?></li>
        </ul>
        </div>
        <?php endif; ?>
  <form action="<?php echo e(route('admin.savebook')); ?>" method="post">
  <?php echo csrf_field(); ?>
    <div class="form-group">
      <label for="name">Book name</label>
      <input class="form-control" id="name" type="text" name="book_name">
    </div>
    <div class="form-group">
      <label for="code">Sku code</label>
      <input class="form-control" id="text" type="text" name="sku_code">
    </div>
    <div class="form-group">
      <label for="message">Author</label>
      <input class="form-control" id="name" type="text" name="author">
    </div>
    <div class="form-group">
      <label for="message">Quantity</label>
      <input class="form-control" id="name" type="number" name="qty">
    </div>
    <br>
    <input class="btn btn-primary" type="submit" value="Submit" />
    </div>
  </form>

           
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/paramjitsingh/Desktop/upwork/manoj/bookstore/resources/views/book/addbook.blade.php ENDPATH**/ ?>