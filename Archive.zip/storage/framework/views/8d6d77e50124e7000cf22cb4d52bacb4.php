<?php $__env->startSection('content'); ?>
<div class="container">

<nav class="navbar navbar-expand-lg navbar-light bg-light">

  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
  <div class="navbar-nav">
      <a class="nav-item nav-link "href="<?php echo e(route('admin.home')); ?>">Dashboard <span class="sr-only"></span></a>
      <a class="nav-item nav-link active" href="<?php echo e(route('admin.viewbooks')); ?>">View books</a>
      <a class="nav-item nav-link " href="<?php echo e(route('admin.addbook')); ?>">Add book</a>
    </div>
  </div>
</nav>

    <div class="row justify-content-center">
        <div class="col-md-8">
            
          
  <h1>View all books</h1>

  <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>


        <?php if(session('success')): ?>
        <div class="alert alert-success">
        <ul>
        <li><?php echo e(session('success')); ?></li>
        </ul>
        </div>
        <?php endif; ?>




        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>S.R.</th>
                                        <th>Book Name</th>
                                        <th>SKU Code</th>
                                        <th>Author</th>
                                        <th>Quanity</th>
                            
                                    </tr>
                                </thead>
                                <tbody>
                                  <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr id="<?php echo e($val->id); ?>">
                                        <td><?php echo e($key+1); ?></td>
                                        <td><?php echo e($val->book_name); ?></td>
                                        <td><?php echo e($val->sku_code); ?></td>
                                        <td><?php echo e($val->author); ?></td>
                                        <td><?php echo e($val->qty); ?></td>

                                    </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>        


           
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/paramjitsingh/Desktop/upwork/manoj/bookstore/resources/views/book/viewbooks.blade.php ENDPATH**/ ?>