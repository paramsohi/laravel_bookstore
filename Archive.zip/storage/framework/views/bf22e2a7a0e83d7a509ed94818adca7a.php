<?php $__env->startSection('content'); ?>

<div class="container">

<nav class="navbar navbar-expand-lg navbar-light bg-light">

  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
  <div class="navbar-nav">
  <a class="nav-item nav-link "href="<?php echo e(route('home')); ?>">Dashboard <span class="sr-only"></span></a>
    <a class="nav-item nav-link active" href="<?php echo e(route('userviewbooks')); ?>">Book list</a>
    <a class="nav-item nav-link " href="<?php echo e(route('bookinhand')); ?>">Book in hand</a>
    </div>
  </div>
</nav>

    <div class="row justify-content-center">
        <div class="col-md-8">
            
          
  <h1>View book</h1>
  <table style="border 2px solid">
      <tr>
          <td>
              Book name :
          </td>
          <td>
              <?php echo e($book->book_name); ?>

          </td>
      </tr>

      <tr>
          <td>
              Book SKU :
          </td>
          <td>
              <?php echo e($book->sku_code); ?>

          </td>
      </tr>

      <tr>
          <td>
              Author :
          </td>
          <td>
              <?php echo e($book->author); ?>

          </td>
      </tr>
  </table>

<br>
<h3>Reviews</h3>
<div class="container">
                <ul>
                    <?php $__currentLoopData = $book->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($r->review); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>


  <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>


        <?php if(session('success')): ?>
        <div class="alert alert-success">
        <ul>
        <li><?php echo e(session('success')); ?></li>
        </ul>
        </div>
        <?php endif; ?>





    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/paramjitsingh/Desktop/upwork/manoj/bookstore/resources/views/user/viewbook.blade.php ENDPATH**/ ?>