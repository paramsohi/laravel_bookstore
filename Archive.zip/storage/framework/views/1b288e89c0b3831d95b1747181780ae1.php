<?php $__env->startSection('content'); ?>
<div class="container">

<nav class="navbar navbar-expand-lg navbar-light bg-light">

  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="navbar-nav">
    <a class="nav-item nav-link "href="<?php echo e(route('home')); ?>">Dashboard <span class="sr-only"></span></a>
    <a class="nav-item nav-link " href="<?php echo e(route('userviewbooks')); ?>">Book list</a>
    <a class="nav-item nav-link " href="<?php echo e(route('userviewbooks')); ?>">Book in hand</a>
   
    </div>
  </div>
</nav>

    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Welcome   <?php echo e(Auth::user()->name); ?></div>
                <div class="card-body">
                    <?php if(session('login-success')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('login-success')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    You are in user dashboard.
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/paramjitsingh/Desktop/upwork/manoj/bookstore/resources/views/home.blade.php ENDPATH**/ ?>